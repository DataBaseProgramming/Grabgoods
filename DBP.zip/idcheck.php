<?
include("./dbcon.php");
$id=$_GET['id'];
$link=mysqli_connect("localhost","root","","grabgoods") or die("db connect error".mysql_error());
$sql="select * from member where id='$_GET['id']'";
$rst=mysqli_query($link,$sql);
$cnt=mysqli_num_rows($link,$rst);
?>
<script type="text/javascript">
function useID(v){
opener.document.all.checkid.value=1;
opener.document.all.id.value=v;
window.close();
}

function chkId(){
var id=document.all.id.value;
if(id){
url="idcheck.php?id="+id;
location.href=url;
}else{
alert("ID�� �Է��ϼ���!");
}
}
</script>
<?if($cnt){?>
<?=$_GET['id']?>�� ����Ͻ� �� ���� ID�Դϴ�<br />
<form>
<input type=text name="id">
<input type=button value="ID�ߺ�Ȯ��" onClick="chkId();">
</form>
<?}else{?>
<?=$_GET['id']?>�� ��밡���� ID�Դϴ�.<br />
<a href="#" onClick="useID('<?=$_GET['id']?>');">����ϱ�</a> <a href="#" onClick="window.close();">�ݱ�</a>
<?}?>