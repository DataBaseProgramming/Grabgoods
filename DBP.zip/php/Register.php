<?php

$id=$_POST['id'];
$password=$_POST['password'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$kakao_id=$_POST['kakao_id'];

$link=mysqli_connect("localhost","root","","grabgoods") or die("db connect error".mysql_error());
$query1="SELECT * FROM member WHERE id='$id'";

$result1=mysqli_query($link,$query1);

$num=0;
$num=mysqli_num_rows($result1);
if($num==0)
{
	if(preg_match('/^[a-zA-Z0-9]{7,10}$/',$id))
	{
		if(preg_match('/^[a-zA-Z0-9]{7,10}$/',$password))
		{
			$query2="INSERT INTO member (id, password, email, phone_number, kakao_id)VALUES('$id','$password','$email','$phone','$kakao_id')";
			$result2=mysqli_query($link,$query2);
			echo "<script>document.location.replace('../login.html');</script>";
		}
	}
	else
	{
		echo '<script>alert("Please write again..");</script>';
		echo "<script>document.location.replace('../registration.html');</script>";
	}
}
else
{
	echo '<script>alert("ID already exists..");</script>';
	echo "<script>document.location.replace('../registration.html');</script>";
}


?>
