<?php
$id=$_POST['id'];
$password=$_POST['password'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$kakao_id=$_POST['kakao_id'];

$link=mysqli_connect("localhost","root","","grabgoods") or die("db connect error".mysql_error());

if(preg_match('/^[a-zA-Z0-9]{7,10}$/',$id))
	{
		if(preg_match('/^[a-zA-Z0-9]{7,10}$/',$password))
		{
			$query="INSERT INTO member (id, password, email, phone_number, kakao_id)VALUES('$id','$password','$email','$phone','$kakao_id')";
			$result=mysqli_query($link,$query);
			echo "<script>document.location.replace('../login.html');</script>";
		}
	}
else
	{
	echo '<script>alert("Please write again..");</script>';
	echo "<script>document.location.replace('../registration.html');</script>";
	}


?>
