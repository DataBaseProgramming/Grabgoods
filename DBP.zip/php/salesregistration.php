
<style = "text/css">
h1{
  font-size: 5em;
  text-align : center;
  padding : 30px;
  }
body{
  background-color:ivory;
}
.bt {
    background-color: #55;
    border: 3px solid;
    color: white;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 50px;
    margin: 4px 2px;
    transition-duration: 0.4s;
    cursor: pointer;
    height : 90px;
    width : 100%;
}
.bt1 {
    background-color: ivory;
    color: black;
    border: 2px solid #555555;
    height : 90px;
    width : 100%
}
.bt1:hover{
    background-color : #555555;
    color:white;
    height : 90px;
    width : 100%;
        }
</style>
<h1>GOODS REGISTER SUCESS</h1>
<?php

	date_default_timezone_set('Asia/Seoul');
	$d = mktime(date("H"),date("i"),date("s"),date("m"),date("d"),date("Y"));	
	$start_time =	date("Y-m-d H : i : s a -> ", $d);
	
	$sellerid=$_POST['sellerid'];
	$goodsname=$_POST['goodsname'];
	$startprice = $_POST['startprice'];
	$end_time = $_POST['end_time'];
	$aboutgoods = $_POST['aboutgoods'];
	
	$target_dir = 'uploads/'
	$target_file = $target_dir . basename($_FILES['userfile']['name']);

	
	$link=mysqli_connect("localhost","root","","grabgoods") or die("db connect error".mysql_error());

	$query="INSERT INTO goodsregister (goodsname,sellerid,startprice,start_time,end_time,image_file,aboutgoods)VALUES('$goodsname','$sellerid','$startprice','$start_time','$end_time','$target_file','$aboutgoods')"; 
	$insert = mysqli_query($link,$query); 
	
	?>
	
	<form action="index.html" method="post" >
		<button class="bt bt1" type="submit" name="new" value=" Go back ">MAIN</button>
	</form>
