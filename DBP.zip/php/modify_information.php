<?php
session_start();
$password=$_POST['password'];
$password_confirm=$_POST['passwordconfirm'];
$email=$_POST['email'];
$phonenumber=$_POST['phonenumber'];
$kakaoid=$_POST['kakaoid'];
$login_id=$_SESSION['login_user'];

$link=mysqli_connect("localhost","root","wlgns710","grabgoods") or die("db connect error".mysql_error());

if(preg_match('/^[a-zA-Z0-9]{7,10}$/',$password))
{
	if(strcmp($password, $password_confirm)==0)
	{
		$query="UPDATE member SET password='$password',email='$email',phone_number='$phonenumber',kakao_id='$kakaoid'WHERE id='$login_id'";
		mysqli_query($link,$query);
		echo "<script>document.location.replace('../main/form.html');</script>";
	}
	else
	{
		echo '<script>alert("Please password write again..");</script>';
		echo "<script>document.location.replace('../main/form.html');</script>";

	}
}
else
{
	echo '<script>alert("Please write again..");</script>';
	echo "<script>document.location.replace('../main/form.html');</script>";
}
mysqli_close($link);
?>

