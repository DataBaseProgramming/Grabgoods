<?php
session_start();
$buyerid=$_SESSION['login_user'];

$bid=$_POST['bid'];


$link=mysqli_connect("localhost","root","","grabgoods") or die("db connect error".mysql_error());
$query="SELECT now_bid FROM goodsregister WHERE goods_num='1'";
$result=mysqli_query($link,$query);
$row=mysqli_fetch_row($result);

if($bid>$row[0])
{

   $query2="UPDATE goodsregister set now_bid = '$bid', buyer_id='$buyerid' where goods_num='1'";
   mysqli_query($link,$query2);
   echo "<script>document.location.replace('../main/index.php');</script>";
}
else
	echo "<script>document.location.replace('../main/index.php');</script>";

?>