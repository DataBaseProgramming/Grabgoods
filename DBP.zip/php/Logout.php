<?php 
//session_start();
//session_destroy();

//echo '<script>window.location="../login.html"</script>';
//echo "<script>document.location.replace('../login.html');</script>";

ini_set("display_errors", "1");
session_start();
session_destroy();
header('Location: ../login.html');


?>