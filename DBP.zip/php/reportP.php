<style = "text/css">
h1{
  font-size: 5em;
  text-align : center;
  padding : 30px;
  }
body{
  background-color:ivory;
}
.bt {
    background-color: #55;
    border: 3px solid;
    color: white;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 50px;
    margin: 4px 2px;
    transition-duration: 0.4s;
    cursor: pointer;
    height : 90px;
    width : 100%;
}
.bt1 {
    background-color: ivory;
    color: black;
    border: 2px solid #555555;
    height : 90px;
    width : 100%
}
.bt1:hover{
    background-color : #555555;
    color:white;
    height : 90px;
    width : 100%;
        }
</style>
<h1>REPORT SUCESS</h1>
<?php
  session_start();
    if(!isset($_SESSION['login_user']))
    {
      header('Location: .../login.html');  
    }
	$report = $_POST['report'];
	$ID_from = $_SESSION['login_user'];
	$ID_to = $_POST['Reported_ID'];
	
	$link=mysqli_connect("localhost","root","","grabgoods") or die("db connect error".mysql_error());

	$query="INSERT INTO report(ID_from,ID_to,reason)VALUES('$ID_from','$ID_to','$report')"; 
	$insert = mysqli_query($link,$query); 
	
	?>
	
	<form action="../main/index.html" method="post" >
		<button class="bt bt1" type="submit" name="new" value=" Go back ">MAIN</button>
	</form>
