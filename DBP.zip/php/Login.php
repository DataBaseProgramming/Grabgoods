<?php
session_start();
$member_id=$_POST['id'];
$member_password=$_POST['password'];


$link=mysqli_connect("localhost","root","","grabgoods") or die("db connect error".mysql_error());

$query="SELECT * FROM member WHERE id='$member_id'";
$result=mysqli_query($link,$query);

$num=0;
$num=mysqli_num_rows($result);
if($num==1)
{
	$_SESSION['login_user']=$member_id;
 	echo "<script>document.location.replace('../main/index.html');</script>";
}
else{
	echo '<script>alert("fail");</script>';
 	echo '<script>window.location="../login.html"</script>';
}
?>