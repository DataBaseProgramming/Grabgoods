 <?php
 $link=mysqli_connect("localhost","root","","grabgoods") or die("db connect error".mysql_error());
 session_start();
if(!isset($_SESSION['login_user']))
{
header('Location: ../login.html');	
}
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="">
		<meta name="author" content="">

		<link rel="icon" href="favicon.ico">
		<title>GrabGoods</title>

		<!-- Bootstrap core CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">

		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		<!-- Custom styles for this template -->

		<link href="css/style.css" rel="stylesheet">

		<style type="text/css">
			.modal-dialog.modal-80size {
 				width: 80%;
 				height: 80%;
 				margin: 0 0 0  0;
 				padding: 0;
			}	

			.modal-content.modal-80size {
				 height: auto;
				 min-height: 100%;
			}

			.modal.modal-center {
			 	text-align: center;
			}

			@media screen and (min-width: 768px) {
			  .modal.modal-center:before {
					display: inline-block;
					vertical-align: middle;
					content: " ";
					height: 100%;
			  }
			}

			.modal-dialog.modal-center {
				display: inline-block;
				text-align: left;
				vertical-align: middle;
			}

			.goods-picture{
				position: relative;
				width: 60%;
				height: 100%;
				display: table;
				background: black;
				float:left;
			}
			.goods-info{
				position: relative;
				overflow: hidden;
				padding: 0 0 0 0px;
				background: white;
				height:100%;
				width:40%;
			}
			.ym-border{
				border-radius:5px;
				border:1px solid #ccc;
				font-size: 16px;
				font-family: 'Open Sans', sans-serif;
			}

			.ym-comment-border{
				border:1px #EAF4FC;
				font-size: 16px;
				font-family: 'Open Sans', sans-serif;
			}

			.modal img {
 			width: inherit;
  			max-width: 80%;
			height: auto;
			}

			.effect-bubba img {
 			width: inherit;
  			max-width: 80%;
			height: auto;
			}

			.container-picture{
				position: relative;
				height: 100%;
				width : 100%;
				display: table;
				background: #333;
			}


			</style>

	</head>
	<body id="page-top">
		<!-- Navigation -->
		<nav class="navbar navbar-default">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<a class="navbar-brand" href="index.php"><img src="images/mainlogo1.png" alt="grabgoodsMainlogo"></a>
				</div>


				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">
						<li>
							<a href="salesregistration.php">Sales Registration</a>
						</li>
						<li>
							<a href="gallery.php">My Page</a>
						</li>
						<li>
                            <a href="report.php">Report</a>
                        </li>

						<li>
							<a href="../php/Logout.php">Logout</a>
						</li>
					</ul>


				</div>
				<!-- /.navbar-collapse -->
			</div>

		</nav>

		<div class="container">
			<form class="form-inline center-block" style="width:300px" role="form">
	 			 <div class="form-group">
	   				<input type="text" class="form-control" placeholder="#" style="width:200px">
	  			</div>
	  			<div class="form-group">
					<input class="btn" type="submin" placeholder="Search" style="width: 90px">
	 			</div>
			</form>
		</div>
     



		<section id="portfolio">
			<div class="container">
   <?php 
                        
	$query = "SELECT count(*) from goodsregister";

	$auction = mysqli_query($link, $query);
	$num=mysqli_fetch_row($auction);

	$n=0;


	for($n=$num[0]; ($n+1)/2 >= 1 ; $n= $n-2)
	{

		?>
		<div class="row row-0-gutter" style="height:400px">
		<?php


		$i=0;
		for($i=$n ; $i > $n-2 ; $i= $i-1)
		{

			if($i>0){
				?><div class="col-md-6 col-0-gutter" style="height:100%">
					<div class="ot-portfolio-item container-picture">	
						<figure class="effect-bubba" style="display: table-cell; text-align: center; vertical-align: middle; ">
							<img src="../photo/<?php
                                        $query="SELECT image FROM goodsregister WHERE goods_num='$i'";
                                        $result=mysqli_query($link,$query);
                                        $row=mysqli_fetch_assoc($result);
                                     	echo $row['image'];
                                     ?>" />
							<figcaption>
								<h2><?php
                                        $query="SELECT goodsname FROM goodsregister WHERE goods_num='$i'";
                                        $result=mysqli_query($link,$query);
                                        $row=mysqli_fetch_assoc($result);
                                     	echo $row['goodsname'];?></h2>
								<p><?php
                                        $query="SELECT aboutgoods FROM goodsregister WHERE goods_num='$i'";
                                        $result=mysqli_query($link,$query);
                                        $row=mysqli_fetch_assoc($result);
                                     	echo $row['aboutgoods'];?></p>
								<a href="#" data-toggle="modal" data-target="#Modal-<?php echo $i ?>">View more</a>
							</figcaption>
						</figure>
					</div>
				</div>



			<?php }

		}
		?> </div> <?php
	}
	?>


			</div><!-- container -->
		</section>

	
<!--<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
<!-- 모달창 엑스 버튼 -->

		<!-- Modal for portfolio item 1 -->
		
<?php
	$n=0;
	for($n=$num[0] ; $n>0 ; $n=$n-1)
	{
		?>
		<div class="modal modal-center fade" id="Modal-<?php echo $n ?>" tabindex="-1" role="dialog" aria-labelledby="Modal-label-<?php echo $n ?>">
			<div class="modal-dialog modal-80size modal-center" role="document">
				<div class="modal-content modal-80size" style="height:100%">
					<div class="modal-body" style="height:100%">
						<div class="goods-picture">
							<div style="display: table-cell; text-align: center; vertical-align: middle; ">
								<img src="../photo/<?php
                                        $query="SELECT image FROM goodsregister WHERE goods_num='$n'";
                                        $result=mysqli_query($link,$query);
                                        $row=mysqli_fetch_assoc($result);
                                     	echo $row['image']; ?>
                                 ">
							</div>
						</div>

						<div class="goods-info" style="height:100%">
							<form class="form-horizontal" style="padding:5px 0 0 0; border:1px solid #ccc; " action="../php/compare_bid.php
							" method="post" enctype="multipart/form-data" role="form">
								<fieldset>
                                <div class="form-group form-group-sm">
                                    <label class="col-sm-3 control-label" for="focusedInput">Seller ID </label>
                                     <div class="com-sm-4">

                                        <text class="ym-border focused" style="width: 200px" id="focusedInput" name="sellerid" >
                                        <?php
                                        $query="SELECT sellerid FROM goodsregister WHERE goods_num='$n'";
                                        $result=mysqli_query($link,$query);
                                        $row=mysqli_fetch_assoc($result);
                                     	echo $row['sellerid'];
                                     ?></text>
                                    </div>
                                </div>

                                <div class="form-group form-group-sm">
                                    <label class="col-sm-3 control-label" for="focusedInput">Goods Name</label>
                                    <div class="com-sm-4">
                                        <text class="ym-border focused" style="width: 200px" id="focusedInput" name="goodsname">
                                         <?php
                                         $query="SELECT goodsname FROM goodsregister WHERE goods_num='$n'";
                                         $result=mysqli_query($link,$query);
                                         $row=mysqli_fetch_assoc($result) ;
                                     	 echo $row['goodsname']; 
                                     	 ?></text>
                                    </div>
                                </div>


                                <div class="form-group form-group-sm">
                                    <label class="col-sm-3 control-label" for="focusedInput">End Time</label>
                                    <div class="com-sm-4">
                                        <text class="ym-border focused" style="width: 200px" id="focusedInput" name="end time">
                                         <?php
                                         $query="SELECT end_time FROM goodsregister WHERE goods_num='$n'";
                                         $result=mysqli_query($link,$query);
                                         $row=mysqli_fetch_assoc($result) ;
                                     	 echo $row['end_time']; 
                                     	 ?></text>
                                    </div>
                                </div>

                                 <div class="form-group form-group-sm">

                                    <label class="col-sm-3 control-label" for="focusedInput">Now Bid</label>
                                    <div class="com-sm-4">
                                        <text class="ym-border focused" style="width: 200px" id="focusedInput"  name="start price">
                                        <?php
                                         $query="SELECT now_bid FROM goodsregister WHERE goods_num='$n'";
                                         $result=mysqli_query($link,$query);
                                         $row=mysqli_fetch_assoc($result) ;
                                     	 echo $row['now_bid']; 
                                     	 ?></text>
                                    </div>
                                </div>

                                <div class="form-group form-group-sm">

                                    <label class="col-sm-3 control-label" for="focusedInput">Bid</label>
                                    <input class="ym-border focused" style="width: 200px" id="focusedInput" type="text"  name="bid" placeholder="">
                                    <button type="submit" class="ym-border">Bid</button>
             					</div>
                            </fieldset>
                          
                        </form>

                     <form class="form-horizontal" action="index.php" style="height:100%; width:100% ;display:table; padding:5px 0 0 0; background:#EAF4FC; "  method="post" enctype="multipart/form-data" role="form">
                            <fieldset style="border-bottom:1px solid #A4C3DB">
                               	<label class="col-sm-3 control-label" for="focusedInput"><?php echo $_SESSION['login_user']?></label>
                        		<input class="focused" style="width: 200px; border-radius:1px;" id="focusedInput" type="text"  name="comment_" placeholder="댓글입력!">

                       			<button type="submit" id="com" style="background: #C7DDEE; border-radius:3px; border:1px solid #A4C3DB">댓글달기</button>
 

                        	



							</fieldset>
							<?php
   			
                   $comment = $_POST['comment_'];
   				if($comment != ""){
   				  $query="INSERT INTO comment(goods_num,comment)VALUES('$n','$comment')"; 
                  $insert = mysqli_query($link,$query); 


					$query_r = "SELECT comment FROM comment WHERE goods_num='$n'";
                  $result = mysqli_query($link,$query_r);


                  echo "</br>"; echo "</br>";
                  while($row = mysqli_fetch_assoc($result)){ 
                   foreach($row as $col_value){
             
                   echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$col_value\n ";
                   echo "</br>";
                   }
                  }
                           
                 
              }

                   ?>  


              		</form>

                      






   
                       </div>

						</div>

					</div>
				</div>
			</div>
		</div>
		<?php } 

		?>



 <!-- Placed at the end of the document so the pages load faster -->
       <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script src="js/SmoothScroll.js"></script>
      <script src="js/theme-scripts.js"></script>

      <script>
$( document ).ready(function() {
});
      </script>

   
   </body>

</html>