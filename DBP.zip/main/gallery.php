 <?php
 $link=mysqli_connect("localhost","root","","grabgoods") or die("db connect error".mysql_error());
 session_start();
 ?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="">
		<meta name="author" content="">

		<link rel="icon" href="favicon.ico">
		<title>GrabGoods</title>

		<!-- Bootstrap core CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">

		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		<!-- Custom styles for this template -->

		<link href="css/style.css" rel="stylesheet">




		<link id="base-style-responsive" href="css/style-responsive.css" rel="stylesheet">
		<link href="css/bootstrap-responsive.min.css" rel="stylesheet">


<style type="text/css">
			.modal-dialog.modal-80size {
 				width: 80%;
 				height: 80%;
 				margin: 0 0 0  0;
 				padding: 0;
			}	

			.modal-content.modal-80size {
				 height: auto;
				 min-height: 100%;
			}

			.modal.modal-center {
			 	text-align: center;
			}

			@media screen and (min-width: 768px) {
			  .modal.modal-center:before {
					display: inline-block;
					vertical-align: middle;
					content: " ";
					height: 100%;
			  }
			}

			.modal-dialog.modal-center {
				display: inline-block;
				text-align: left;
				vertical-align: middle;
			}

			.goods-picture{
				position: relative;
				width: 60%;
				height: 100%;
				display: table;
				background: black;
				float:left;
			}
			.goods-info{
				position: relative;
				overflow: hidden;
				padding: 0 0 0 0px;
				background: white;
				height:100%;
				width:40%;
			}
			.ym-border{
				border-radius:5px;
				border:1px solid #ccc;
				font-size: 16px;
				font-family: 'Open Sans', sans-serif;
			}

			.ym-comment-border{
				border:1px #EAF4FC;
				font-size: 16px;
				font-family: 'Open Sans', sans-serif;
			}

			.modal img {
 			width: inherit;
  			max-width: 80%;
			height: auto;
			}

			.effect-bubba img {
 			width: inherit;
  			max-width: 80%;
			height: auto;
			}

			.container-picture{
				position: relative;
				height: 100%;
				display: table;
				background: #333;
			}


			</style>


	</head>
	<body id="page-top">
		<!-- Navigation -->
		<nav class="navbar navbar-default">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<a class="navbar-brand" href="index.php"><img src="images/mainlogo1.png" alt="grabgoodsMainlogo"></a>
				</div>


				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">
						<li>
							<a href="salesregistration.php">Sales Registration</a>
						</li>
						<li>
							<a href="gallery.php">My Page</a>
						</li>
						<li>
                            <a href="report.php">Report</a>
                        </li>
						<li>
							<a href="../php/Logout.php">Logout</a>
						</li>
					</ul>


				</div>
				<!-- /.navbar-collapse -->
			</div>

		</nav>

		<div class="container">
			<form class="form-inline center-block" style="width:300px" role="form">
	 			 <div class="form-group">
	   				<input type="text" class="form-control" placeholder="#" style="width:200px">
	  			</div>
	  			<div class="form-group">
					<input class="btn" type="submin" placeholder="Search" style="width: 90px">
	 			</div>
			</form>
		</div>


<div class="container-fluid-full">
	<div class="row-fluid">
			<!-- start: Content -->
		<div id="content" class="span10">
			
						
			<ul class="breadcrumb">
				<div class="center-block list-inline" style="width: 230px">
				<li>
					<a href="gallery.php">My Auction</a> 
				</li><li>/</li>
				<li>
					<a href="form.php">Profile Modify</a> 
				</li>
				</div>
			</ul>

			<div class="row-fluid sortable">
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i></i><span class="break"></span> Goods</h2>
					
					</div>
					<div class="box-content">
						<div class="masonry-gallery" >

						<?php 

                     
							$query = "SELECT count(*) from goodsregister";

							$auction = mysqli_query($link, $query);
							$num=mysqli_fetch_row($auction);

							$n=0;


							for($n=$num[0] ; $n>0 ; $n=$n-1){

								?>
							<div id="image-<?php echo $n ?>" class="masonry-thumb">
								<figcaption>
									<a href="#" data-toggle="modal" data-target="#Modal-<?php echo $n ?>"><img class="grayscale" src="../photo/<?php
                                        $query="SELECT image FROM goodsregister WHERE goods_num='$n'";
                                        $result=mysqli_query($link,$query);
                                        $row=mysqli_fetch_assoc($result);
                                     	echo $row['image'];
                                     ?>"></a>
								</figcaption>
							</div>
						<?php } ?>
							
						</div>
					</div>
				</div><!--/span-->
			</div><!--/row-->
		</div>
	</div>
</div>


<?php
	$n=0;
	for($n=$num[0] ; $n>0 ; $n=$n-1)
	{
		?>
		<div class="modal modal-center fade" id="Modal-<?php echo $n ?>" tabindex="-1" role="dialog" aria-labelledby="Modal-label-<?php echo $n ?>">
			<div class="modal-dialog modal-80size modal-center" role="document">
				<div class="modal-content modal-80size" style="height:100%">
					<div class="modal-body" style="height:100%">
						<div class="goods-picture">
							<div style="display: table-cell; text-align: center; vertical-align: middle; ">
								<img src="../photo/<?php
                                        $query="SELECT image FROM goodsregister WHERE goods_num='$n'";
                                        $result=mysqli_query($link,$query);
                                        $row=mysqli_fetch_assoc($result);
                                     	echo $row['image']; ?>
                                 ">
							</div>
						</div>

						<div class="goods-info" style="height:100%">
							<form class="form-horizontal" style="padding:5px 0 0 0; border:1px solid #ccc; " action="../php/compare_bid.php
							" method="post" enctype="multipart/form-data" role="form">
								<fieldset>
                                <div class="form-group form-group-sm">
                                    <label class="col-sm-3 control-label" for="focusedInput">Seller ID </label>
                                     <div class="com-sm-4">

                                        <text class="ym-border focused" style="width: 200px" id="focusedInput" name="sellerid" >
                                        <?php
                                        $query="SELECT sellerid FROM goodsregister WHERE goods_num='$n'";
                                        $result=mysqli_query($link,$query);
                                        $row=mysqli_fetch_assoc($result);
                                     	echo $row['sellerid'];
                                     ?></text>
                                    </div>
                                </div>

                                <div class="form-group form-group-sm">
                                    <label class="col-sm-3 control-label" for="focusedInput">Goods Name</label>
                                    <div class="com-sm-4">
                                        <text class="ym-border focused" style="width: 200px" id="focusedInput" name="goodsname">
                                         <?php
                                         $query="SELECT goodsname FROM goodsregister WHERE goods_num='$n'";
                                         $result=mysqli_query($link,$query);
                                         $row=mysqli_fetch_assoc($result) ;
                                     	 echo $row['goodsname']; 
                                     	 ?></text>
                                    </div>
                                </div>


                                <div class="form-group form-group-sm">
                                    <label class="col-sm-3 control-label" for="focusedInput">End Time</label>
                                    <div class="com-sm-4">
                                        <text class="ym-border focused" style="width: 200px" id="focusedInput" name="end time">
                                         <?php
                                         $query="SELECT end_time FROM goodsregister WHERE goods_num='$n'";
                                         $result=mysqli_query($link,$query);
                                         $row=mysqli_fetch_assoc($result) ;
                                     	 echo $row['end_time']; 
                                     	 ?></text>
                                    </div>
                                </div>

                                 <div class="form-group form-group-sm">

                                    <label class="col-sm-3 control-label" for="focusedInput">Now Bid</label>
                                    <div class="com-sm-4">
                                        <text class="ym-border focused" style="width: 200px" id="focusedInput"  name="start price">
                                        <?php
                                         $query="SELECT now_bid FROM goodsregister WHERE goods_num='$n'";
                                         $result=mysqli_query($link,$query);
                                         $row=mysqli_fetch_assoc($result) ;
                                     	 echo $row['now_bid']; 
                                     	 ?></text>
                                    </div>
                                </div>

                                <div class="form-group form-group-sm">

                                    <label class="col-sm-3 control-label" for="focusedInput">Bid</label>
                                    <input class="ym-border focused" style="width: 200px" id="focusedInput" type="text"  name="bid" placeholder="">
                                    <button type="submit" class="ym-border">Bid</button>
             					</div>
                            </fieldset>
                            <text type="hidden" name="comment_" value="">

                        </form>

                     <form class="form-horizontal" action="index.php" style="height:100%; width:100% ;display:table; padding:5px 0 0 0; background:#EAF4FC; "  method="post" enctype="multipart/form-data" role="form">
                            <fieldset style="border-bottom:1px solid #A4C3DB">
                               	<label class="col-sm-3 control-label" for="focusedInput"><?php echo $_SESSION['login_user']?></label>
                        		<input class="focused" style="width: 200px; border-radius:1px;" id="focusedInput" type="text"  name="comment_" placeholder="댓글입력!">
                       			<button type="submit" id="com" style="background: #C7DDEE; border-radius:3px; border:1px solid #A4C3DB">댓글달기</button>
                        	



							</fieldset>
							<?php
   
                   $comment = $_POST['comment_'];
   				if($comment != ""){
   				  $query="INSERT INTO comment(goods_num,comment)VALUES('$n','$comment')"; 
                  $insert = mysqli_query($link,$query); 


					$query_r = "SELECT comment FROM comment WHERE goods_num='$n'";
                  $result = mysqli_query($link,$query_r);


                  echo "</br>"; echo "</br>";
                  while($row = mysqli_fetch_assoc($result)){ 
                   foreach($row as $col_value){
             
                   echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$col_value\n ";
                   echo "</br>";
                   }
                  }
                           
                 
              }

                   ?>  


              		</form>

                      






   
                       </div>

						</div>

					</div>
				</div>
			</div>
		</div>
		<?php } 

		?>
		<!-- Bootstrap core JavaScript
			================================================== -->
		<!-- Placed at the end of the document so the pages load faster -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/SmoothScroll.js"></script>
		<script src="js/theme-scripts.js"></script>


		<script src="mypage/js/jquery-1.9.1.min.js"></script>
	<script src="mypage/js/jquery-migrate-1.0.0.min.js"></script>
	
		<script src="mypage/js/jquery-ui-1.10.0.custom.min.js"></script>
	
		<script src="mypage/js/jquery.ui.touch-punch.js"></script>
	
		<script src="mypage/js/modernizr.js"></script>
	
		<script src="mypage/js/bootstrap.min.js"></script>
	
		<script src="mypage/js/jquery.cookie.js"></script>
	
		<script src='mypage/js/fullcalendar.min.js'></script>
	
		<script src='mypage/js/jquery.dataTables.min.js'></script>

		<script src="mypage/js/excanvas.js"></script>
	<script src="mypage/js/jquery.flot.js"></script>
	<script src="mypage/js/jquery.flot.pie.js"></script>
	<script src="mypage/js/jquery.flot.stack.js"></script>
	<script src="mypage/js/jquery.flot.resize.min.js"></script>
	
		<script src="mypage/js/jquery.chosen.min.js"></script>
	
		<script src="mypage/js/jquery.uniform.min.js"></script>
		
		<script src="mypage/js/jquery.cleditor.min.js"></script>
	
		<script src="mypage/js/jquery.noty.js"></script>
	
		<script src="mypage/js/jquery.elfinder.min.js"></script>
	
		<script src="mypage/js/jquery.raty.min.js"></script>
	
		<script src="mypage/js/jquery.iphone.toggle.js"></script>
	
		<script src="mypage/js/jquery.uploadify-3.1.min.js"></script>
	
		<script src="mypage/js/jquery.gritter.min.js"></script>
	
		<script src="mypage/js/jquery.imagesloaded.js"></script>
	
		<script src="mypage/js/jquery.masonry.min.js"></script>
	
		<script src="mypage/js/jquery.knob.modified.js"></script>
	
		<script src="mypage/js/jquery.sparkline.min.js"></script>
	
		<script src="mypage/js/counter.js"></script>
	
		<script src="mypage/js/retina.js"></script>

		<script src="mypage/js/custom.js"></script>

	</body>
</html>