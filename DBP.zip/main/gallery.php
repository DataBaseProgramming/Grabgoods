<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="">
		<meta name="author" content="">

		<link rel="icon" href="favicon.ico">
		<title>GrabGoods</title>

		<!-- Bootstrap core CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">

		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		<!-- Custom styles for this template -->

		<link href="css/style.css" rel="stylesheet">




		<link id="base-style-responsive" href="css/style-responsive.css" rel="stylesheet">
		<link href="css/bootstrap-responsive.min.css" rel="stylesheet">





	</head>
	<body id="page-top">
		<!-- Navigation -->
		<nav class="navbar navbar-default">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="index.html"><img src="images/mainlogo1.png" alt="Treviso theme logo"></a>
				</div>


				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">
						<li class="hidden">
							<a href="#page-top"></a>
						</li>

						<li>
							<a href="salesregistration.php">Sales Registration</a>
						</li>
						<li>
							<a href="gallery.php">My Page</a>
						</li>
						<li>
                            <a href="report.php">Report</a>
                        </li>
						<li>
							<a href="../php/Logout.php">Logout</a>
						</li>
					</ul>


				</div>
				<!-- /.navbar-collapse -->
			</div>

		</nav>

		<div class="container">
			<form class="form-inline center-block" style="width:300px" role="form">
	 			 <div class="form-group">
	   				<input type="text" class="form-control" placeholder="#" style="width:200px">
	  			</div>
	  			<div class="form-group">
					<input class="btn" type="submin" placeholder="Search" style="width: 90px">
	 			</div>
			</form>
		</div>


<div class="container-fluid-full">
	<div class="row-fluid">
			<!-- start: Content -->
		<div id="content" class="span10">
			
						
			<ul class="breadcrumb">
				<div class="center-block list-inline" style="width: 230px">
				<li>
					<a href="gallery.php">My Auction</a> 
				</li><li>/</li>
				<li>
					<a href="form.php">Profile Modify</a> 
				</li>
				</div>
			</ul>

			<div class="row-fluid sortable">
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i></i><span class="break"></span> Goods</h2>
					
					</div>
					<div class="box-content">
						<div class="masonry-gallery" >
							<div id="image-1" class="masonry-thumb">
								<figcaption>
									<a href="#" data-toggle="modal" data-target="#Modal-1"><img class="grayscale" src="mypage/img/gallery/photo1.jpg" alt="Sample Image 1"></a>
								</figcaption>
							</div>

							<div id="image-2" class="masonry-thumb">
								<figcaption>
									<a href="#" data-toggle="modal" data-target="#Modal-2"><img class="grayscale" src="mypage/img/gallery/photo2.jpg" alt="Sample Image 2"></a>
								</figcaption>
							</div>

							<div id="image-3" class="masonry-thumb">
								<figcaption>
									<a href="#" data-toggle="modal" data-target="#Modal-3"><img class="grayscale" src="mypage/img/gallery/photo3.jpg" alt="Sample Image 3"></a>
								</figcaption>
							</div>

							<div id="image-4" class="masonry-thumb">
								<figcaption>
								<a href="#" data-toggle="modal" data-target="#Modal-4"><img class="grayscale" src="mypage/img/gallery/photo4.jpg" alt="Sample Image 4"></a>
								</figcaption>
							</div>

							<div id="image-5" class="masonry-thumb">
								<figcaption>
								<a href="#" data-toggle="modal" data-target="#Modal-5"><img class="grayscale" src="mypage/img/gallery/photo5.jpg" alt="Sample Image 5"></a>
								</figcaption>
							</div>

							<div id="image-6" class="masonry-thumb">
								<figcaption>
								<a href="#" data-toggle="modal" data-target="#Modal-6"><img class="grayscale" src="mypage/img/gallery/photo6.jpg" alt="Sample Image 6"></a>
								</figcaption>
							</div>

							<div id="image-7" class="masonry-thumb">
								<figcaption>
								<a href="#" data-toggle="modal" data-target="#Modal-7"><img class="grayscale" src="mypage/img/gallery/photo7.jpg" alt="Sample Image 7"></a>
								</figcaption>
							</div>

							<div id="image-8" class="masonry-thumb">
								<figcaption>
								<a href="#" data-toggle="modal" data-target="#Modal-8"><img class="grayscale" src="mypage/img/gallery/photo8.jpg" alt="Sample Image 8"></a>
								</figcaption>
							</div>

							<div id="image-9" class="masonry-thumb">
								<figcaption>
								<a href="#" data-toggle="modal" data-target="#Modal-9"><img class="grayscale" src="mypage/img/gallery/photo9.jpg" alt="Sample Image 9"></a>
								</figcaption>
							</div>

							<div id="image-10" class="masonry-thumb">
								<figcaption>
								<a href="#" data-toggle="modal" data-target="#Modal-10"><img class="grayscale" src="mypage/img/gallery/photo10.jpg" alt="Sample Image 10"></a>
								</figcaption>
							</div>

							<div id="image-11" class="masonry-thumb">
								<figcaption>
								<a href="#" data-toggle="modal" data-target="#Modal-11"><img class="grayscale" src="mypage/img/gallery/photo11.jpg" alt="Sample Image 11"></a>
								</figcaption>
							</div>

							<div id="image-12" class="masonry-thumb">
								<figcaption>
								<a href="#" data-toggle="modal" data-target="#Modal-12"><img class="grayscale" src="mypage/img/gallery/photo12.jpg" alt="Sample Image 12"></a>
								</figcaption>
							</div>

							<div id="image-13" class="masonry-thumb">
								<figcaption>
								<a href="#" data-toggle="modal" data-target="#Modal-13"><img class="grayscale" src="mypage/img/gallery/photo13.jpg" alt="Sample Image 13"></a>
								</figcaption>
							</div>

							<div id="image-14" class="masonry-thumb">
								<figcaption>
								<a href="#" data-toggle="modal" data-target="#Modal-14"><img class="grayscale" src="mypage/img/gallery/photo5.jpg" alt="Sample Image 5"></a>
								</figcaption>
							</div>

							<div id="image-15" class="masonry-thumb">
								<figcaption>
								<a href="#" data-toggle="modal" data-target="#Modal-15"><img class="grayscale" src="mypage/img/gallery/photo2.jpg" alt="Sample Image 2"></a>
								</figcaption>
							</div>
						</div>
					</div>
				</div><!--/span-->
			</div><!--/row-->
		</div>
	</div>
</div>
		<!-- Bootstrap core JavaScript
			================================================== -->
		<!-- Placed at the end of the document so the pages load faster -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/SmoothScroll.js"></script>
		<script src="js/theme-scripts.js"></script>


		<script src="mypage/js/jquery-1.9.1.min.js"></script>
	<script src="mypage/js/jquery-migrate-1.0.0.min.js"></script>
	
		<script src="mypage/js/jquery-ui-1.10.0.custom.min.js"></script>
	
		<script src="mypage/js/jquery.ui.touch-punch.js"></script>
	
		<script src="mypage/js/modernizr.js"></script>
	
		<script src="mypage/js/bootstrap.min.js"></script>
	
		<script src="mypage/js/jquery.cookie.js"></script>
	
		<script src='mypage/js/fullcalendar.min.js'></script>
	
		<script src='mypage/js/jquery.dataTables.min.js'></script>

		<script src="mypage/js/excanvas.js"></script>
	<script src="mypage/js/jquery.flot.js"></script>
	<script src="mypage/js/jquery.flot.pie.js"></script>
	<script src="mypage/js/jquery.flot.stack.js"></script>
	<script src="mypage/js/jquery.flot.resize.min.js"></script>
	
		<script src="mypage/js/jquery.chosen.min.js"></script>
	
		<script src="mypage/js/jquery.uniform.min.js"></script>
		
		<script src="mypage/js/jquery.cleditor.min.js"></script>
	
		<script src="mypage/js/jquery.noty.js"></script>
	
		<script src="mypage/js/jquery.elfinder.min.js"></script>
	
		<script src="mypage/js/jquery.raty.min.js"></script>
	
		<script src="mypage/js/jquery.iphone.toggle.js"></script>
	
		<script src="mypage/js/jquery.uploadify-3.1.min.js"></script>
	
		<script src="mypage/js/jquery.gritter.min.js"></script>
	
		<script src="mypage/js/jquery.imagesloaded.js"></script>
	
		<script src="mypage/js/jquery.masonry.min.js"></script>
	
		<script src="mypage/js/jquery.knob.modified.js"></script>
	
		<script src="mypage/js/jquery.sparkline.min.js"></script>
	
		<script src="mypage/js/counter.js"></script>
	
		<script src="mypage/js/retina.js"></script>

		<script src="mypage/js/custom.js"></script>

	</body>
</html>