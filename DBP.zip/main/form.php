<?php
session_start();
if(!isset($_SESSION['login_user']))
{
header('Location: ../login.html');	
}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="">
		<meta name="author" content="">

		<link rel="icon" href="favicon.ico">
		<title>GrabGoods</title>

		<!-- Bootstrap core CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">

		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		<!-- Custom styles for this template -->

		<link href="css/style.css" rel="stylesheet">




		<link id="base-style-responsive" href="css/style-responsive.css" rel="stylesheet">
		<link href="css/bootstrap-responsive.min.css" rel="stylesheet">



</head>

	<body id="page-top">
		<!-- Navigation -->
		<nav class="navbar navbar-default">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<a class="navbar-brand" href="index.php"><img src="images/mainlogo1.png" alt="grabgoodsMainlogo"></a>
				</div>


				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">
						<li>
							<a href="salesregistration.php">Sales Registration</a>
						</li>
						<li>
							<a href="gallery.php">My Page</a>
						</li>
						<li>
                            <a href="report.php">Report</a>
                        </li>
						<li>
							<a href="../php/Logout.php">Logout</a>
						</li>
					</ul>


				</div>
				<!-- /.navbar-collapse -->
			</div>

		</nav>

		<div class="container">
			<form class="form-inline center-block" style="width:300px" role="form">
	 			 <div class="form-group">
	   				<input type="text" class="form-control" placeholder="#" style="width:200px">
	  			</div>
	  			<div class="form-group">
					<input class="btn" type="submin" placeholder="Search" style="width: 90px">
	 			</div>
			</form>
		</div>




     




	
<div class="container-fluid-full">
	<div class="row-fluid">
		<!-- start: Content -->
		<div id="content" class="span10">
			
						
			<ul class="breadcrumb">
				<div class="center-block list-inline" style="width: 230px">
				<li>
					<a href="gallery.php">My Auction</a> 
				</li><li>/</li>
				<li>
					<a href="form.php">Profile Modify</a> 
				</li>
				</div>
			</ul>

			<div class="row-fluid sortable">
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon white edit"></i><span class="break"></span>Modify information</h2>
					</div>
					<div class="box-content">

						<form class="form-horizontal" action="../php/modify_information.php" method="post" role="form">
							<fieldset>
								<div class="form-group form-group-sm">
									<label class="col-sm-2 control-label" for="disabledInput">ID</label>
									<div class="com-sm-4">
								 		<input class="form-control disabled" style="width: 200px" id="disabledInput" type="text" placeholder="<?php echo $_SESSION['login_user']?>" disabled="">
									</div>
								</div>

								<div class="form-group form-group-sm">
									<label class="col-sm-2 control-label" for="focusedInput">Password</label>
									<div class="com-sm-4">
										<input class="form-control focused" style="width: 200px" id="focusedInput" type="password"  name="password" placeholder="password">
									</div>
								</div>

								<div class="form-group form-group-sm">
									<label class="col-sm-2 control-label" for="focusedInput">Password Confirm</label>
									<div class="com-sm-4">
										<input class="form-control focused" style="width: 200px" id="focusedInput" type="password" name="passwordconfirm" placeholder="password confirm">
									</div>
								</div>


								<div class="form-group form-group-sm">
									<label class="col-sm-2 control-label" for="focusedInput">Email</label>
									<div class="com-sm-4">
										<input class="form-control focused" style="width: 200px" id="focusedInput" type="email" name="email" placeholder="Ex) *****@Gmail.com">
									</div>
								</div>

								<div class="form-group form-group-sm">
									<label class="col-sm-2 control-label" for="focusedInput">Phone</label>
									<div class="controls">
										<input class="form-control focused" style="width: 200px" id="focusedInput" type="tel" name="phonenumber" placeholder="Phone number">
									</div>
								</div>

								<div class="form-group form-group-sm">
									<label class="col-sm-2 control-label" for="focusedInput">Kakao ID</label>
									<div class="controls">
										<input class="form-control focused" style="width: 200px" id="focusedInput" type="text" name="kakaoid" placeholder="Kakao ID">
									</div>
								</div>

							  <div class="form-actions">
								<button type="submit" class="btn btn-primary">Save changes</button>
								<button class="btn">Cancel</button>
							  </div>

							</fieldset>
						  </form>
					</div>
				</div><!--/span-->
			</div><!--/row-->
		</div>
	</div>
</div>
		

	
	<!-- start: JavaScript-->

		<script src="mypage/js/jquery-1.9.1.min.js"></script>
	<script src="mypage/js/jquery-migrate-1.0.0.min.js"></script>
	
		<script src="mypage/js/jquery-ui-1.10.0.custom.min.js"></script>
	
		<script src="mypage/js/jquery.ui.touch-punch.js"></script>
	
		<script src="mypage/js/modernizr.js"></script>
	
		<script src="mypage/js/bootstrap.min.js"></script>
	
		<script src="mypage/js/jquery.cookie.js"></script>
	
		<script src='mypage/js/fullcalendar.min.js'></script>
	
		<script src='mypage/js/jquery.dataTables.min.js'></script>

		<script src="mypage/js/excanvas.js"></script>
	<script src="mypage/js/jquery.flot.js"></script>
	<script src="mypage/js/jquery.flot.pie.js"></script>
	<script src="mypage/js/jquery.flot.stack.js"></script>
	<script src="mypage/js/jquery.flot.resize.min.js"></script>
	
		<script src="mypage/js/jquery.chosen.min.js"></script>
	
		<script src="mypage/js/jquery.uniform.min.js"></script>
		
		<script src="mypage/js/jquery.cleditor.min.js"></script>
	
		<script src="mypage/js/jquery.noty.js"></script>
	
		<script src="mypage/js/jquery.elfinder.min.js"></script>
	
		<script src="mypage/js/jquery.raty.min.js"></script>
	
		<script src="mypage/js/jquery.iphone.toggle.js"></script>
	
		<script src="mypage/js/jquery.uploadify-3.1.min.js"></script>
	
		<script src="mypage/js/jquery.gritter.min.js"></script>
	
		<script src="mypage/js/jquery.imagesloaded.js"></script>
	
		<script src="mypage/js/jquery.masonry.min.js"></script>
	
		<script src="mypage/js/jquery.knob.modified.js"></script>
	
		<script src="mypage/js/jquery.sparkline.min.js"></script>
	
		<script src="mypage/js/counter.js"></script>
	
		<script src="mypage/js/retina.js"></script>

		<script src="mypage/js/custom.js"></script>
	<!-- end: JavaScript-->
	
</body>
</html>
