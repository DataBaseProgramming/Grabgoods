<?php
session_start();
if(!isset($_SESSION['login_user']))
{
header('Location: ../login.html');  
}
?>
<!DOCTYPE html>
<html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <meta name="description" content="">
        <meta name="author" content="">

        <link rel="icon" href="favicon.ico">
        <title>GrabGoods</title>

        <!-- Bootstrap core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
        <!-- Custom styles for this template -->

        <link href="css/style.css" rel="stylesheet">




        <link id="base-style-responsive" href="css/style-responsive.css" rel="stylesheet">
        <link href="css/bootstrap-responsive.min.css" rel="stylesheet">



</head>

    <body id="page-top">
        <!-- Navigation -->
        <nav class="navbar navbar-default">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <a class="navbar-brand" href="index.php"><img src="images/mainlogo1.png" alt="grabgoodsMainlogo"></a>
                </div>


                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="salesregistration.php">Sales Registration</a>
                        </li>
                        <li>
                            <a href="gallery.php">My Page</a>
                        </li>
                        <li>
                            <a href="report.php">Report</a>
                        </li>
                        <li>
                            <a href="../php/Logout.php">Logout</a>
                        </li>
                    </ul>


                </div>
                <!-- /.navbar-collapse -->
            </div>

        </nav>
        <div class="container">
            <form class="form-inline center-block" style="width:300px" role="form">
                 <div class="form-group">
                    <input type="text" class="form-control" placeholder="#" style="width:200px">
                </div>
                <div class="form-group">
                    <input class="btn" type="submin" placeholder="Search" style="width: 90px">
                </div>
            </form>
        </div>




 <div class="container-fluid-full">
    <div class="row-fluid">
        <!-- start: Content -->
        <div id="content" class="span10">
            
                        
            <ul class="breadcrumb">
                <div class="center-block list-inline" style="width: 230px">
                <li>
                    
                </li>

                </div>
            </ul>
    

<body>

            <div class="row-fluid sortable">
                <div class="box span12">
                    <div class="box-header" data-original-title>
                        <h2><i class="halflings-icon white edit"></i><span class="break"></span>Sales Registration</h2>
                    </div>
                    <div class="box-content">

                        <form class="form-horizontal" action="../php/salesregistration.php" method="post" enctype="multipart/form-data" role="form">
                            <fieldset>
                                <div class="form-group form-group-sm">
                                    <label class="col-sm-2 control-label" for="disabledInput">My ID</label>
                                    <div class="com-sm-4">
                                        <input class="form-control disabled" style="width: 200px" id="disabledInput" type="text" name="sellerid" placeholder="<?php echo $_SESSION['login_user']?>" disabled="">
                                    </div>
                                </div>

                                <div class="form-group form-group-sm">
                                    <label class="col-sm-2 control-label" for="focusedInput">GoodsName</label>
                                    <div class="com-sm-4">
                                        <input class="form-control focused" style="width: 200px" id="focusedInput" type="text"  name="goodsname" placeholder="">
                                    </div>
                                </div>

                                <div class="form-group form-group-sm">
                                    <label class="col-sm-2 control-label" for="focusedInput">StartPrice</label>
                                    <div class="com-sm-4">
                                        <input class="form-control focused" style="width: 200px" id="focusedInput" type="text"  name="startprice" placeholder="">
                                    </div>
                                </div>

                                <div class="form-group form-group-sm">
                                    <label class="col-sm-2 control-label" for="focusedInput">End Auction Time</label>
                                    <div class="com-sm-4">
                                        <select class="form-control focused" style="width: 200px" id="focusedInput" type="datetime-local"  name="end_time" >
                                            <option value="24">After 24 hours</option>
                                            <option value="48">After 48 hours</option>
                                            <option value="72">After 72 hours</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group form-group-sm">
                                    <label class="col-sm-2 control-label" for="focusedInput">About Goods
                                        <textarea name="aboutgoods" rows="20" cols="150"></textarea>
                                    </label>
                                </div>
                                <br/>
                                File Upload &nbsp;&nbsp; <input type="hidden" name="MAX_FILE_SIZE" value="5242880" />
		                            <input type="hidden" name="mode" value="upload" />
		                            <input type="file" name="imagefile" id="imagefile" />

                              <div class="form-actions">
                                <button type="submit" class="btn btn-primary">Registration</button>
                                <button class="btn">Cancel</button>
                              </div>

                            </fieldset>
                          </form>
                    </div>
                </div><!--/span-->
            </div><!--/row-->
        </div>
    </div>
</div>


</body>

</html>